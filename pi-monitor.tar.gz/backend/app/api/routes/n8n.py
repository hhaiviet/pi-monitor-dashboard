from fastapi import APIRouter, HTTPException
from app.services import n8n_manager

router = APIRouter()

@router.get("/status")
def get_status():
    status = n8n_manager.get_status()
    return {"status": status}

@router.post("/start")
def start_n8n():
    if n8n_manager.start_service():
        return {"status": "success", "message": "Service started"}
    raise HTTPException(status_code=500, detail="Failed to start service")

@router.post("/stop")
def stop_n8n():
    if n8n_manager.stop_service():
        return {"status": "success", "message": "Service stopped"}
    raise HTTPException(status_code=500, detail="Failed to stop service")

@router.post("/restart")
def restart_n8n():
    if n8n_manager.restart_service():
        return {"status": "success", "message": "Service restarted"}
    raise HTTPException(status_code=500, detail="Failed to restart service")

@router.get("/logs")
def get_logs():
    logs = n8n_manager.get_logs()
    return {"logs": logs}
