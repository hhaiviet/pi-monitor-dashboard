from fastapi import APIRouter, HTTPException
from app.services import system_monitor

router = APIRouter()

@router.get("/stats")
def get_stats():
    return system_monitor.get_system_stats()

@router.get("/info")
def get_info():
    return system_monitor.get_system_info()

@router.get("/processes")
def get_processes():
    return system_monitor.get_processes()

@router.post("/processes/{pid}/kill")
def kill_process(pid: int):
    success = system_monitor.kill_process(pid)
    if not success:
        raise HTTPException(status_code=404, detail="Process not found")
    return {"status": "success", "message": f"Process {pid} terminated"}
