import subprocess
import os

N8N_SERVICE = os.getenv("N8N_SERVICE_NAME", "n8n")

def run_command(command):
    try:
        result = subprocess.run(command, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        return True, result.stdout
    except subprocess.CalledProcessError as e:
        return False, e.stderr

def get_status():
    success, output = run_command(f"systemctl is-active {N8N_SERVICE}")
    if success:
        return "active" if "active" in output else "inactive"
    return "unknown"

def start_service():
    success, _ = run_command(f"sudo systemctl start {N8N_SERVICE}")
    return success

def stop_service():
    success, _ = run_command(f"sudo systemctl stop {N8N_SERVICE}")
    return success

def restart_service():
    success, _ = run_command(f"sudo systemctl restart {N8N_SERVICE}")
    return success

def get_logs(lines=100):
    success, output = run_command(f"journalctl -u {N8N_SERVICE} -n {lines} --no-pager")
    if success:
        return output.splitlines()
    return []
