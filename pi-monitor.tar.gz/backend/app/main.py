from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.routes import system, n8n, websocket
from app.api.routes import router as api_router
import os
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(title="Pi Monitor API", version="1.0.0")

origins = os.getenv("ALLOWED_ORIGINS", "*").split(",")

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix="/api")
# WebSocket router is often handled separately or included
app.include_router(websocket.router, prefix="/ws")

@app.get("/")
def read_root():
    return {"status": "online", "service": "Pi Monitor API"}
